# ProyectoCorte2
Página web para contabilizar y estudiar los datos de los estudiantes.
